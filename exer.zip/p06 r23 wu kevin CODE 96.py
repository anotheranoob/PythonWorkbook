def main():
    password = input("Enter a password: ")
    if isGoodPassword(password):
        print("That is a good password")
    else:
        print("That is a bad password")


def isGoodPassword(password):
    includesUpper = False
    includesLower = False
    includesNumber = False
    print(len(password))
    for letter in password:
        if letter.isupper():
            includesUpper = True
        if letter.islower():
            includesLower = True
        if letter.isdigit():
            includesNumber = True
    if includesUpper and includesLower and includesNumber and len(password) >= 8:
        return True
    return False

main()