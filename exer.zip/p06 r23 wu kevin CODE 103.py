def main():
    magicDates = []
    months = {"1": "31", "2": "28", "3": "31", "4": "30", "5": "31", "6": "30", "7": "31", "8": "31", "9": "30", "10": "31", "11": "30", "12": "31"}
    for year in range(1, 100):
        for month in months:
            for day in range(int(months[month])):
                if isMagicDate(int(year), int(month), int(day)):
                    magicDates.append("/".join([month, str(day), str(year+1900)]))
    print("The dates are", ", ".join(magicDates))


def isMagicDate(year, month, day):
    if year % 100 == month * day:
        return True
    return False


main()