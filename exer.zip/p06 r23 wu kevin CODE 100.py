def main():
    months = {"1": "31", "2": "28", "3": "31", "4": "30", "5": "31", "6": "30", "7": "31", "8": "31", "9": "30",
              "10": "31", "11": "30", "12": "31"}
    month = input("What month is it as a number?: ")
    if month != "2":
        return months[month]
    else:
        year = input("What year is it as a number?: ")
        if int(year) % 4 == 0 and (not(int(year) % 100 == 0 ) or int(year) % 400 == 0):
            print(int(months[month])+1)
        else:
            print(months[month])