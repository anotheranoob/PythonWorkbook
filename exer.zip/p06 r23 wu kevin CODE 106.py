def main():
    values = []
    currentInput = input("Enter an integer: ")
    while currentInput != "":
        values.append(int(currentInput))
        currentInput = input("Enter an integer: ")
    if len(values)<=4:
        print("That is not a valid list")
        return
    else:
        values.sort()
        print("The list is now", values[2:-2])

main()