def main():
    values = []
    currentInput = input("Enter a word: ")
    while currentInput != "":
        if not currentInput in values:
            values.append(currentInput)
        currentInput = input("Enter a word: ")
    print(values)

main()