def main():
    values = []
    currentInput = input("Enter an integer: ")
    while currentInput != "0":
        values.append(int(currentInput))
        currentInput = input("Enter an integer: ")
    values.sort(reverse=True)
    print(values)


main()