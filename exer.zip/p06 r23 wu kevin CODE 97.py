import random
import string


def passwordGenerator():
    passwordLen = random.randint(0, 32)
    password = []
    chars = string.ascii_letters+string.digits
    for _ in range(passwordLen):
        password.append(random.choice(chars))

    return "".join(password)


def isGoodPassword(password):
    includesUpper = False
    includesLower = False
    includesNumber = False
    for letter in password:
        if letter.isupper():
            includesUpper = True
        if letter.islower():
            includesLower = True
        if letter.isdigit():
            includesNumber = True
    if includesUpper and includesLower and includesNumber and len(password) >= 8:
        return True
    return False


def main():
    password = passwordGenerator()
    numTries = 1
    while not isGoodPassword(password):
        password = passwordGenerator()
        numTries += 1
    print("The password", password, "took", numTries, "tries to be generated")


main()
